HOW TO USE AT WORK - Aviation Dashboard (offline copy)
Data shown at startup is fictional for demonstration. Not an official Iowa National Guard product.
When you load your own files, the footer switches to: "Showing data loaded from your files on this device. Nothing is uploaded."

WHAT'S HERE
  command-dashboard.html          Single self-contained file. Double-click to open in Edge or Chrome.
  folder-version/index.html   Same dashboard as a folder of files (use if a single large file is blocked).
  templates/           Blank templates with the exact column headers.

OPEN IT
  1. Unzip to your desktop or a SharePoint/OneDrive-synced folder on your computer.
  2. Double-click command-dashboard.html. It runs entirely in the browser; it makes no network requests
     and needs no install. (Opening it inside the SharePoint web viewer will not run it; use the synced copy.)

LOAD YOUR DATA
  - Click "Load files" (or drag files onto the bar) and pick one or more Excel/CSV exports.
  - Files are read by this browser tab only. Nothing is uploaded or sent. Close the tab to clear it.
  - The load report ("Show details") lists rows loaded, columns matched, and anything that could not be read.

SAVE A COPY WITH YOUR DATA BUILT IN (so others can open it without loading files)
  1. Open command-dashboard.html and load your files. Check the load report.
  2. Click "Save with data". The browser downloads COMMAND-REAL-DATA-<date>.html (for example
     COMMAND-REAL-DATA-29Oct26.html) with the loaded records inside it. Nothing is uploaded.
  3. Put that file ONLY in the restricted SharePoint folder (unique permissions, access requests on).
     It contains real data: do not email it, post it, or put it in any code repository, website, or shared/public location.
  4. To update it: open the saved file, click "Load files" (or "Add more files") with the newer exports,
     then "Save with data" again and replace the old file in the restricted folder.
  The saved file shows a red "Contains real data" banner with the save date/time and source file names.
  "Clear" in a saved file goes back to its built-in data; "Restore demo data" shows the fictional data.

PRESENTING / PRINTING
  - "Presentation mode" hides the loading and help panels (Esc exits). "Print / PDF" prints the dashboard.

DATA HANDLING
  Follow your organization's policies for the source data. Do not save real exports into a shared copy of this
  folder. The only thing the page remembers is whether the details panel was open (browser storage).
