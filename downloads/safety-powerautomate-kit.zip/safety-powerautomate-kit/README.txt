SAFETY DASHBOARD - POWER AUTOMATE AUTO-REFRESH KIT
Everything here is fictional demo data until your flow fills it in. No personal or external links.

WHAT'S HERE
  dashboard-template.html            Upload to the restricted SharePoint library (the flow reads it; never edit it there).
  POWER-AUTOMATE-SETUP-GUIDE.html    Step-by-step build guide (open in Edge; Print / PDF button at the top).
  POWER-AUTOMATE-SETUP-GUIDE.md      Same guide as plain text.
  EXPRESSIONS.txt                    Every expression to copy and paste into the flow.
  templates/asmis_tracker_table.xlsx Blank tracker already formatted as a Table named MishapTracker.

IN SHORT
  1. In every tracker and the roll-up: Ctrl+T, Table Name = MishapTracker, save as .xlsx.
  2. Upload dashboard-template.html, plus a copy renamed SAFETY-REAL-DATA.html, to the restricted library.
  3. Build the scheduled flow in the guide (Recurrence 0600/1200 Central -> list .xlsx files -> List rows (MishapTracker)
     -> append {file, rows} -> Get file content (template) -> Compose replace -> Update file SAFETY-REAL-DATA.html).
  4. Point the home page Quick links button at SAFETY-REAL-DATA.html (Copy link > People with existing access).

SAFETY-REAL-DATA.html contains real records: keep it only in the restricted library. Never email or post it.
